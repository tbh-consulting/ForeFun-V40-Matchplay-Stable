/*
  # Initial Badge Calculation

  1. Execute
    - Run initial badge calculation for all users
*/

-- Calculate badges for all existing users
SELECT calculate_all_user_badges();